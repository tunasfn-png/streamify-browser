@echo off
REM ═══════════════════════════════════════════════════════════════════
REM  Streamify Browser v0.2.0 – Script de compilación para Windows 11
REM ═══════════════════════════════════════════════════════════════════
REM
REM  Requisitos:
REM    1. Rust toolchain (rustup.rs) – stable, target x86_64-pc-windows-msvc
REM    2. Visual Studio Build Tools 2022 (o VS 2022 con C++ workload)
REM    3. WebView2 Runtime (preinstalado en Windows 11)
REM
REM  Uso:
REM    COMPILAR_WINDOWS11.cmd          → compilación release
REM    COMPILAR_WINDOWS11.cmd debug    → compilación debug
REM ═══════════════════════════════════════════════════════════════════

setlocal enabledelayedexpansion

echo.
echo  ╔══════════════════════════════════════╗
echo  ║   Streamify Browser v0.2.0           ║
echo  ║   Compilación nativa Win32+WebView2  ║
echo  ╚══════════════════════════════════════╝
echo.

REM Verificar Rust
where rustc >nul 2>&1
if errorlevel 1 (
    echo [ERROR] No se encontró rustc. Instala Rust desde https://rustup.rs
    exit /b 1
)

REM Verificar target
rustup target list --installed | findstr /i "x86_64-pc-windows-msvc" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Añadiendo target x86_64-pc-windows-msvc...
    rustup target add x86_64-pc-windows-msvc
)

REM Modo de compilación
set MODE=release
set CARGO_FLAG=--release
if /i "%1"=="debug" (
    set MODE=debug
    set CARGO_FLAG=
)

echo [INFO] Modo: %MODE%
echo [INFO] Compilando...
echo.

cargo build %CARGO_FLAG% --target x86_64-pc-windows-msvc

if errorlevel 1 (
    echo.
    echo [ERROR] La compilación falló. Revisa los errores arriba.
    exit /b 1
)

echo.
echo [OK] Compilación exitosa.

set EXE_PATH=target\x86_64-pc-windows-msvc\%MODE%\streamify-browser.exe

if exist "%EXE_PATH%" (
    echo [OK] Ejecutable: %EXE_PATH%

    REM Mostrar tamaño
    for %%F in ("%EXE_PATH%") do (
        set /a SIZE_KB=%%~zF / 1024
        echo [OK] Tamaño: !SIZE_KB! KB
    )
) else (
    echo [WARN] No se encontró el ejecutable en %EXE_PATH%
)

echo.
echo  Para ejecutar:
echo    %EXE_PATH%
echo.

endlocal
